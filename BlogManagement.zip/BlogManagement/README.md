User credential 

email  : ayushmaj46@gmail.com
password : 123456


email  : admin@gmail.com
password : 123456