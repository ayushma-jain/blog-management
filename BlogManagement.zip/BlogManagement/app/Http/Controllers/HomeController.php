<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use Illuminate\Support\Facades\Auth;
use DB;
use Validator;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
		$data = array();
		
		$data['blogData'] = DB::table('blog_details')->get()->toArray();
	
        return view('home',$data);
    }
	/**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function welcome()
    {
		$data = array();
		
		$data['blogData'] = DB::table('blog_details')->where(['status'=>'Active'])->get()->toArray();
	
        return view('welcome',$data);
    }
	
	
	public function addEditBlog(Request $request){
		
		$inputData = $request->all();
		$loginId = Auth::user()->id;
		/* 	$rule = $request->validate([
            'blogTitle' => 'required',
            'blogImage' => 'required',
            'blogDescription' => 'required',
            'blogTags' => 'required',
        ]);
	
		$validator = Validator::make($inputData,$rule);
		echo '<pre>'; print_r($validator->fails());exit;
		if($validator->fails()) {
			return Redirect::back()->withErrors($validator);
		} */
		$blogTitle = isset($inputData['blogTitle']) ? $inputData['blogTitle'] : '';
		$blogDescription = isset($inputData['blogDescription']) ? $inputData['blogDescription'] : '';
		$blogTags = isset($inputData['blogTags']) ? $inputData['blogTags'] : '';
		$actionType = isset($inputData['actionType']) ? $inputData['actionType'] : 'Add';
		$blogId = isset($inputData['blogId']) ? $inputData['actionType'] : 'blogId';
		
		$blogImage = $request->file('blogImage');
		
		$imagePath = '';
		if ($blogImage != "")
		{
			$imageName = time().$blogImage->getClientOriginalName();
			$imagePath = 'images/'.$imageName;
			$blogImage->move(public_path().'/images/', $imageName);
		}
		if($actionType == 'Edit' && !empty($blogId)){
			$blog  = new Blog;
			DB::table('blog_details')->where(['id' => $blogId])->update(['title' =>$blogTitle , 'description' => $blogDescription , 'tags' =>  $blogTags, 'image' => $imagePath]);
			return redirect()->back()->with('success', 'Blog updated successfully');
		}else{
			$blog  = new Blog;
			$blog->title = $blogTitle;
			$blog->description  = $blogDescription;
			$blog->tags = $blogTags;
			$blog->image = $imagePath;
			$blog->created_by = $loginId;
			if($blog->save()){
				return redirect()->back()->with('success', 'Blog Added successfully');
			}
		}
	}
	
	
	
	public function getBlogAddEditView(Request $request){
		$inputData = $request->all();
		$actionType = isset($inputData['actionType']) ? $inputData['actionType'] : 'Add';
		$blogId = isset($inputData['blogId']) ? base64_decode($inputData['blogId']) : 0;
		$blogData = array();
		if($actionType == 'Edit' && !empty($blogId)){
			$blogData =DB::table('blog_details')->where(['id'=>$blogId,'status'=>'Active'])->get()->first();
		}
		
		$returnHTML = view('add-edit-blog-view')->with(['actionType' => $actionType,'blogData'=> $blogData])->render();
	
		return $returnHTML;
	}
	
	public function deleteBlog($blogId){
		$blogId = isset($blogId) ? base64_decode($blogId) : 0;
		if(!empty($blogId)){
			DB::table('blog_details')->where(['id'=>$blogId])->delete();
			return redirect()->back()->with('success', 'Blog deleted successfully!!');
		}
		return redirect()->back()->with('error', 'Something went wrong!!');
	}
}
