<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	$data = array();
		
	$data['blogData'] = DB::table('blog_details')->where(['status'=>'Active'])->get()->toArray();

	
    return view('welcome',$data);
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::post('/create-blog', [App\Http\Controllers\HomeController::class, 'addEditBlog'])->name('create-blog');
Route::get('/delete-blog/{id}', [App\Http\Controllers\HomeController::class, 'deleteBlog'])->name('delete-blog');
Route::post('/blog-add-edit-view', [App\Http\Controllers\HomeController::class, 'getBlogAddEditView'])->name('blog-add-edit-view');

