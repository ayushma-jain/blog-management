@extends('layouts.app')

@section('content')
<div class="m-5">
    <div class="row justify-content-center">
			@if($errors->any())
				<div class="alert alert-danger col-12">
					@foreach ($errors->all() as $error)
						<div>{{ $error }}</div>
					@endforeach
				</div>
			@endif
			@if(session()->has('error'))
				<div class="alert alert-danger col-12">
					{{ session()->get('error') }}
				</div>
			@endif
			@if(session()->has('success'))
				<div class="alert alert-success col-12">
					{{ session()->get('success') }}
				</div>
			@endif
		</div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
					<div class="row">
						<div class="col-12 text-right">
							<button class="btn btn-success openAddEditBolgView" type="Add">Add Blog</button>
						</div>
						<div class="col-12 mt-4">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Title</th>
										<th class="w-50">Description</th>
										<th>Tags</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									@if(isset($blogData) && count($blogData) > 0)
										@php $index =1; @endphp
										@foreach($blogData as $blog)
											<tr>
												<td>{{ $index }}</td>
												<td>
													@if(isset($blog->image) && !empty($blog->image))
														<img class="blogImage" src="{{ asset($blog->image)}}">
														{{ isset( $blog->title ) ?  $blog->title : ''}}
													@endif
												</td>
												<td class="w-50">{{ isset( $blog->description ) ?  $blog->description : ''}}</td>
												<td>{{ isset( $blog->tags ) ?  $blog->tags : ''}}</td>
												<td>
													@if(isset( $blog->created_by) && $blog->created_by == Auth::user()->id)
														<button class="btn btn-primary openAddEditBolgView" type="Edit" rel="{{base64_encode($blog->id)}}">Edit</button>
														<a type="button" class="btn btn-danger" href="{{route('delete-blog',[base64_encode($blog->id)]) }}">Delete</button>
													@endif
												</td>
											</tr>
											@php $index++; @endphp
										@endforeach
									@else
										
										<tr>
											<td colspan="5"> No Blog Found!!</td>
										</tr>
									@endif
								</tbody>
							</table>
						</div>
					</div>
					
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addEditBlogModalView" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	
</div>


@endsection

