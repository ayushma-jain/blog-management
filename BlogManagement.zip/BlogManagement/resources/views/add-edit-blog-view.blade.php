<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modalHeading">Add Bolg</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-12">
						<form method="post" id="addEditBlogForm"  action="{{ route('create-blog') }}" enctype="multipart/form-data">
							@csrf
							<input type="hidden" id="actionType" name="actionType" value="{{isset($actionType) ? $actionType : 'Add'}}">
							<input type="hidden" id="blogId" name="blogId" value="{{isset($blogData->id) ? $blogData->id : ''}}">
							<div class="form-group">
								<label for="blogTitle">Title</label>
								<input type="text" class="form-control checkBlk allowMaxLength" autocomplete="off" max="255" id="blogTitle"  name="blogTitle" placeholder="Title Name"  value="{{isset($blogData->title) ? $blogData->title : ''}}"/>
								<div class="text-danger errorMsg" id="err_blogTitle"></div>
							</div>
							<div class="form-group">
								<label for="exampleInputPassword1">Description</label>
								<textarea class="form-control checkBlk allowMaxLength" max="65535" id="blogDescription"  autocomplete="off" rows="8" name="blogDescription" placeholder="Type Description Here...">{{isset($blogData->description) ? $blogData->description : ''}}</textarea>
								<div class="text-danger errorMsg" id="err_blogDescription"></div>
							</div>
							<div class="form-group">
								<label for="blogTags">Tags</label>
								<input type="text" class="form-control checkBlk" id="blogTags" autocomplete="off" name="blogTags" placeholder="Add Tags" value="{{isset($blogData->tags) ? $blogData->tags : ''}}"/>
								<div class="text-danger errorMsg" id="err_blogTags"></div>
							</div>
							<div class="form-group">
								<label for="blogTags">Blog Image</label>
								<input type="file" class="form-control checkBlk imageUpload" id="blogImage" autocomplete="off" name="blogImage" placeholder="Upload Image" accept="image/png, image/gif, image/jpeg" value="{{isset($blogData->image) ? $blogData->image : ''}}" />
								<div class="text-danger errorMsg" id="err_blogImage"></div>
							</div>
							<div class="form-group text-center">
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" id="createNewBlog">Save changes</button>
			</div>
		</div>
	</div>