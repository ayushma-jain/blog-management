/**
File Name : common.js
Description : File is used for all common js
Date : 22/May/2021
**/

$(function(){
	
	$(document).on('click','.openAddEditBolgView',function(){

		var actionType = $(this).attr('type');
		var blogId = $(this).attr('rel');
		$.ajax({
			type:'POST',
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			url:$('#hf_base_url').val()+'/blog-add-edit-view',
			data:{'actionType' : actionType ,'blogId' : blogId},
			success:function(response) {
				
				$("#addEditBlogModalView").html(response);
				$("#addEditBlogModalView").modal('show');
			}
		},'HTML');
		
	});
	
	$(document).on('click','#createNewBlog',function(event)
	{
		event.preventDefault();
		$('.error').text("");
		$('.checkBlk').removeClass('required');
		$('.checkBlk').each(function()
		{
			var elementId = $(this).attr('id');
			var elementValue = $(this).val();
			var countBlank =0;
			if(elementValue == '' || elementValue == undefined){
				//$('#err_'+elementId).text("This field value is required!!");
				$('#'+elementId).addClass('required');
				countBlank++;
			}
			if(countBlank == 0){
				
				$('#addEditBlogForm').submit();
			
			}
		});
	});
	
	$(document).on('change','.imageUpload',function()
	{
		$('#err_blogImage').text('');
		var uploadedFile = $(this);
		var imageFileSize = uploadedFile[0].files[0].size;
		var imageFileName = uploadedFile[0].files[0].name;
		var splitImageName = imageFileName.split('.');
		var imageExtension = splitImageName[splitImageName.length - 1];
		var allowedExtensionArray = ['png','jpeg','gif','jpg'];
		
		if(imageFileSize > 102100){
			$('#err_blogImage').text("You can not upload this image.Maximum uploaded image size is 100Kb!!");
			$(this).val('');
			return false;
		}
		
		if($.inArray(imageExtension,allowedExtensionArray) < 0){
			$('#err_blogImage').text("Only image files extension('jpg,png,gif') are allowed!!");
			$(this).val('');
			return false;
		}
	})
	
	$(document).on('change keyup input','.allowMaxLength',function(event){
		
		var elementId = $(this).attr('id');
		var stringValue = $(this).val();
		var valueLength = $(this).val().length;
		var maxAllowedLength = $(this).attr('max');
		if(valueLength > maxAllowedLength){
			$('#err_'+elementId).text(maxAllowedLength+" characters are allowed!!");
			$(this).val(stringValue.substring(0, maxAllowedLength));
			return false;
		}
	});
});