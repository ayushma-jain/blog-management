<?php $__env->startSection('content'); ?>
<div class="m-5">
    <div class="row justify-content-center">
			<?php if($errors->any()): ?>
				<div class="alert alert-danger col-12">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div><?php echo e($error); ?></div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>
			<?php if(session()->has('error')): ?>
				<div class="alert alert-danger col-12">
					<?php echo e(session()->get('error')); ?>

				</div>
			<?php endif; ?>
			<?php if(session()->has('success')): ?>
				<div class="alert alert-success col-12">
					<?php echo e(session()->get('success')); ?>

				</div>
			<?php endif; ?>
		</div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
					<div class="row">
						<div class="col-12 text-right">
							<button class="btn btn-success openAddEditBolgView" type="Add">Add Blog</button>
						</div>
						<div class="col-12 mt-4">
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Title</th>
										<th class="w-50">Description</th>
										<th>Tags</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php if(isset($blogData) && count($blogData) > 0): ?>
										<?php $index =1; ?>
										<?php $__currentLoopData = $blogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($index); ?></td>
												<td>
													<?php if(isset($blog->image) && !empty($blog->image)): ?>
														<img class="blogImage" src="<?php echo e(asset($blog->image)); ?>">
														<?php echo e(isset( $blog->title ) ?  $blog->title : ''); ?>

													<?php endif; ?>
												</td>
												<td class="w-50"><?php echo e(isset( $blog->description ) ?  $blog->description : ''); ?></td>
												<td><?php echo e(isset( $blog->tags ) ?  $blog->tags : ''); ?></td>
												<td>
													<?php if(isset( $blog->created_by) && $blog->created_by == Auth::user()->id): ?>
														<button class="btn btn-primary openAddEditBolgView" type="Edit" rel="<?php echo e(base64_encode($blog->id)); ?>">Edit</button>
														<a type="button" class="btn btn-danger" href="<?php echo e(route('delete-blog',[base64_encode($blog->id)])); ?>">Delete</button>
													<?php endif; ?>
												</td>
											</tr>
											<?php $index++; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										
										<tr>
											<td colspan="5"> No Blog Found!!</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
					
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addEditBlogModalView" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AyushmaPersonal\Laravel\BlogManagement\resources\views/home.blade.php ENDPATH**/ ?>